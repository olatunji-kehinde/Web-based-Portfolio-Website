<?php
// Simple landing page linking to admin and scanner
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Wedding Invitation Generator</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;700&family=Poppins&display=swap" rel="stylesheet">
  <style>
    body {
      background: #f9fdfd;
      font-family: 'Poppins', sans-serif;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
    header {
      background: rgba(0,77,74,0.95);
      color: #fff;
      text-align: center;
      padding: 2rem 1rem;
      border-bottom: 3px solid #c19a3f;
      font-family: 'Cormorant Garamond', serif;
      animation: fadeInDown 1s ease-in-out;
    }
    header h1 {
      font-size: 2.5rem;
      margin-bottom: .5rem;
    }
    header p {
      font-size: 1rem;
      opacity: 0.85;
    }
    main {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 3rem 1rem;
    }
    .card {
      border-radius: 1rem;
      border: none;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      animation: fadeInUp 1s ease-in-out;
    }
    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 20px rgba(0,0,0,0.15);
    }
    .btn-custom {
      background: #004d4a;
      color: #fff;
      border: none;
      border-radius: 30px;
      padding: .6rem 1.4rem;
      font-weight: 500;
      transition: background 0.3s ease;
    }
    .btn-custom:hover {
      background: #006d68;
    }
    .btn-outline-custom {
      border: 2px solid #004d4a;
      color: #004d4a;
      border-radius: 30px;
      padding: .6rem 1.4rem;
      font-weight: 500;
      transition: all 0.3s ease;
    }
    .btn-outline-custom:hover {
      background: #004d4a;
      color: #fff;
    }
    footer {
      background: rgba(0,77,74,0.95);
      color: #fff;
      text-align: center;
      padding: 1rem;
      border-top: 3px solid #c19a3f;
      font-size: 0.9rem;
      animation: fadeInUp 1s ease-in-out;
    }
    footer span {
      color: #c19a3f;
      font-weight: 600;
    }
    @keyframes fadeInDown {
      from { opacity: 0; transform: translateY(-20px); }
      to { opacity: 1; transform: translateY(0); }
    }
    @keyframes fadeInUp {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>
<body>
  <header>
    <h1>Mesh'25 Wedding Invitation Generator</h1>
    <p>Create elegant QR-ready wedding cards & manage guest check-ins</p>
  </header>

  <main>
    <div class="container">
      <div class="row g-4 justify-content-center">
        <div class="col-12 col-md-5">
          <div class="card shadow-sm p-4 text-center">
            <h5 class="card-title mb-3">Admin Dashboard</h5>
            <p class="text-muted mb-4">Add guests and print traditional, elegant invitations.</p>
            <a class="btn btn-custom" href="admin/index.php">Open Admin</a>
          </div>
        </div>
        <div class="col-12 col-md-5">
          <div class="card shadow-sm p-4 text-center">
            <h5 class="card-title mb-3">Entrance Scanner</h5>
            <p class="text-muted mb-4">Scan QR codes and check in guests quickly.</p>
            <a class="btn btn-outline-custom" href="scanner/index.php">Open Scanner</a>
          </div>
        </div>
      </div>
    </div>
  </main>

<footer>
  <div>💐 Mesh'25 Wedding | Designed with <span>❤️</span> By Popkot Consult</div>
</footer>
</body>
</html>
