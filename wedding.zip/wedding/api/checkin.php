<?php
header('Content-Type: application/json');
require __DIR__ . '/../includes/db.php';

$payload = json_decode(file_get_contents('php://input'), true);
$code = trim($payload['code'] ?? '');
$delta = intval($payload['delta'] ?? 0);

if (!$code || $delta === 0) {
    echo json_encode(['ok'=>false, 'error'=>'Invalid request']); exit;
}

$stmt = $conn->prepare("SELECT id, name, num_allowed, table_number, checked_in_count FROM guests WHERE code = ? LIMIT 1");
$stmt->bind_param("s", $code);
$stmt->execute();
$res = $stmt->get_result();
$g = $res->fetch_assoc();
$stmt->close();

if (!$g) { echo json_encode(['ok'=>false, 'error'=>'Guest not found']); exit; }

$newCount = $g['checked_in_count'] + $delta;
if ($newCount < 0) $newCount = 0;
if ($newCount > $g['num_allowed']) {
    echo json_encode(['ok'=>false, 'error'=>'Cannot check in beyond permitted number']); exit;
}

$upd = $conn->prepare("UPDATE guests SET checked_in_count = ? WHERE id = ?");
$upd->bind_param("ii", $newCount, $g['id']);
$upd->execute();
$upd->close();

$g['checked_in_count'] = $newCount;
echo json_encode(['ok'=>true, 'message'=>'Updated check-in count', 'guest'=>$g]);
