<?php
header('Content-Type: application/json');
require __DIR__ . '/../includes/db.php';

$code = trim($_GET['code'] ?? '');
if (!$code) {
    echo json_encode(['ok'=>false, 'error'=>'Missing code']); exit;
}

$stmt = $conn->prepare("SELECT id, code, name, num_allowed, table_number, checked_in_count FROM guests WHERE code = ? LIMIT 1");
$stmt->bind_param("s", $code);
$stmt->execute();
$res = $stmt->get_result();
$guest = $res->fetch_assoc();
$stmt->close();

if (!$guest) {
    echo json_encode(['ok'=>false, 'error'=>'Code not found']); exit;
}

echo json_encode(['ok'=>true, 'guest'=>$guest]);
