<?php
require __DIR__ . '/../includes/db.php'; // not used directly but ensures env is loaded
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Entrance Scanner — Wedding Invites</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="/assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
  <div class="row g-4">
    <!-- Scanner -->
    <div class="col-12 col-lg-6">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5 class="card-title">Scan QR</h5>
          <div id="reader" style="width:100%;"></div>
          <div class="mt-3">
            <button id="toggleCam" class="btn btn-outline-dark btn-sm">Switch Camera</button>
          </div>
          <p class="text-muted small mt-2 mb-0">Tip: increase screen brightness for paper tickets.</p>
        </div>
      </div>
    </div>

    <!-- Guest Details -->
    <div class="col-12 col-lg-6">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5 class="card-title">Guest Details</h5>
          <div id="result" class="small text-muted">Awaiting scan...</div>
          <div id="guestCard" class="mt-3 d-none">
            <ul class="list-group">
              <li class="list-group-item"><strong>Name:</strong> <span id="g_name"></span></li>
              <li class="list-group-item"><strong>Admits:</strong> <span id="g_admits"></span></li>
              <li class="list-group-item"><strong>Table:</strong> <span id="g_table"></span></li>
              <li class="list-group-item"><strong>Checked in:</strong> <span id="g_checked"></span></li>
            </ul>
            <div class="d-flex gap-2 mt-3">
              <button id="btnOne" class="btn btn-dark">Check in 1 person</button>
              <button id="btnUndo" class="btn btn-outline-secondary">Undo last</button>
            </div>
            <div id="actionMsg" class="mt-2 small"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
<script>
const urlBase = ""; // same origin
const resultEl = document.getElementById("result");
const guestCard = document.getElementById("guestCard");
const gName = document.getElementById("g_name");
const gAdmits = document.getElementById("g_admits");
const gTable = document.getElementById("g_table");
const gChecked = document.getElementById("g_checked");
const btnOne = document.getElementById("btnOne");
const btnUndo = document.getElementById("btnUndo");
const actionMsg = document.getElementById("actionMsg");
const toggleCamBtn = document.getElementById("toggleCam");

let currentCode = new URLSearchParams(location.search).get('code') || null;
let scanner = new Html5Qrcode("reader");
let devicesList = [];
let currentCamId = null;

function showGuest(data){
  guestCard.classList.remove('d-none');
  gName.textContent = data.name;
  gAdmits.textContent = data.num_allowed;
  gTable.textContent = data.table_number;
  gChecked.textContent = data.checked_in_count;
}

async function fetchGuest(code){
  resultEl.textContent = "Checking code...";
  const resp = await fetch(`/api/get_guest.php?code=${encodeURIComponent(code)}`);
  const data = await resp.json();
  if (data.ok) {
    resultEl.textContent = "Valid QR code";
    showGuest(data.guest);
  } else {
    resultEl.textContent = data.error || "Invalid or unknown code";
    guestCard.classList.add('d-none');
  }
}

async function checkin(delta){
  if (!currentCode) return;
  const resp = await fetch('/api/checkin.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ code: currentCode, delta })
  });
  const data = await resp.json();
  if (data.ok) {
    actionMsg.textContent = data.message;
    showGuest(data.guest);
  } else {
    actionMsg.textContent = data.error || "Action failed";
  }
}

btnOne.addEventListener('click', () => checkin(1));
btnUndo.addEventListener('click', () => checkin(-1));

function onScanSuccess(decodedText, decodedResult) {
  currentCode = decodedText.trim();
  fetchGuest(currentCode);
}
function onScanFailure(error) {}

if (currentCode) {
  fetchGuest(currentCode);
}

function startScanner(camId) {
  if (scanner._isScanning) {
    scanner.stop().then(() => {
      scanner.start(camId, { fps: 10, qrbox: 250 }, onScanSuccess, onScanFailure);
    });
  } else {
    scanner.start(camId, { fps: 10, qrbox: 250 }, onScanSuccess, onScanFailure);
  }
}

Html5Qrcode.getCameras().then(devices => {
  if (!devices || devices.length === 0) {
    resultEl.textContent = "No camera found.";
    return;
  }

  devicesList = devices;

  // pick back camera if available
  const backCam = devices.find(d => /back|rear|environment/i.test(d.label));
  currentCamId = backCam ? backCam.id : devices[0].id;
  startScanner(currentCamId);

}).catch(err => {
  resultEl.textContent = "Camera access error: " + err;
});

// Toggle between cameras
toggleCamBtn.addEventListener("click", () => {
  if (devicesList.length < 2) return; // nothing to switch
  const currentIndex = devicesList.findIndex(d => d.id === currentCamId);
  const nextIndex = (currentIndex + 1) % devicesList.length;
  currentCamId = devicesList[nextIndex].id;
  startScanner(currentCamId);
});
</script>
</body>
</html>
