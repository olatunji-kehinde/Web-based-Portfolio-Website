<?php 
require __DIR__ . '/../includes/db.php';
require __DIR__ . '/../includes/helpers.php';
require_login();

// Fetch guests
$q = $conn->query("SELECT * FROM guests ORDER BY id DESC");
$guests = $q ? $q->fetch_all(MYSQLI_ASSOC) : [];

// ✅ Fetch seat counts per table (handles comma-separated values properly)
$table_counts = [];

$res = $conn->query("SELECT table_number, num_allowed FROM guests");
while ($row = $res->fetch_assoc()) {
    $tables = array_map('trim', explode(',', $row['table_number']));
    $num_tables = count($tables);
    $per_table = intdiv($row['num_allowed'], $num_tables); // base seats per table
    $remainder = $row['num_allowed'] % $num_tables;        // distribute leftovers

    foreach ($tables as $index => $t) {
        if (!isset($table_counts[$t])) {
            $table_counts[$t] = 0;
        }
        $add = $per_table + ($index < $remainder ? 1 : 0); // fair distribution
        $table_counts[$t] = min(10, $table_counts[$t] + $add); // cap at 10
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Dashboard — Mesh'25 Invites</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">

  <style>
    body {
      background: #f8f9fa;
      font-family: "Poppins", sans-serif;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
    main { flex: 1; }

    @keyframes fadeDown { from { opacity: 0; transform: translateY(-20px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes fadeUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }

    .navbar { background: linear-gradient(90deg, #004d4a, #007f7c); animation: fadeDown 1s ease-out; }
    .navbar-brand { font-weight: 600; font-size: 1.25rem; color: #fff !important; }

    .card {
      border: none;
      border-radius: 1rem;
      background: #ffffff;
      box-shadow: 0 4px 12px rgba(0,0,0,0.08);
      opacity: 0; 
      transform: translateY(20px);
      animation: fadeUp 0.9s ease-out forwards;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .card:hover { transform: translateY(-5px); box-shadow: 0 6px 18px rgba(0,0,0,0.12); }
    .card:nth-of-type(1) { animation-delay: 0.3s; }
    .card:nth-of-type(2) { animation-delay: 0.6s; }

    .card-title { font-weight: 600; color: #004d4a; }
    .btn-dark { background-color: #004d4a; border: none; }
    .btn-dark:hover { background-color: #007f7c; }

    .table th { background-color: #004d4a; color: #fff; }
    .table-striped tbody tr:nth-of-type(odd) { background-color: rgba(0, 77, 74, 0.05); }

    footer {
      background: rgba(0, 77, 74, 0.95);
      color: #fff;
      text-align: center;
      padding: 1rem 0;
      font-size: 0.9rem;
      border-top: 3px solid #c19a3f;
      font-family: "Poppins", sans-serif;
      letter-spacing: 0.5px;
      opacity: 0;
      transform: translateY(20px);
      animation: fadeUp 1.2s ease-out forwards;
    }
    footer span { color: #c19a3f; font-weight: 600; }

    code { color: #c17f00; font-weight: 600; }

    .select2-container .select2-selection--single { height: 42px !important; padding: 6px 12px; border: 1px solid #ced4da; border-radius: 0.375rem; }
    .select2-container--default .select2-selection--single .select2-selection__arrow { top: 8px; right: 8px; }
  </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark shadow-sm">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php">💍 Mesh'25 Wedding Invites</a>
    <div class="d-flex">
      <a class="btn btn-outline-light" href="logout.php">Logout</a>
    </div>
  </div>
</nav>

<main>
  <div class="container py-5">
    <?php if (isset($_GET['error']) && $_GET['error'] === 'TableFull'): ?>
      <div class="alert alert-danger">
        ❌ Table <strong><?= e($_GET['table']) ?></strong> is already full.
        <?php if (isset($_GET['left']) && intval($_GET['left']) > 0): ?>
          Only <strong><?= intval($_GET['left']) ?></strong> seats left.
        <?php else: ?>
          No seats remaining.
        <?php endif; ?>
      </div>
    <?php elseif (isset($_GET['success'])): ?>
      <div class="alert alert-success">
        ✅ Guest added successfully.
      </div>
    <?php endif; ?>

    <div class="row g-4">
      <!-- Add Guest -->
      <div class="col-12 col-lg-4">
        <div class="card h-100">
          <div class="card-body">
            <h5 class="card-title">➕ Add Guest</h5>
            <form action="add_guest.php" method="post" class="mt-3">
              <div class="row g-3">
                <div class="col-7">
                  <label class="form-label">Guest Name</label>
                  <input type="text" name="name" class="form-control" required>
                </div>
                <div class="col-md-5">
                  <label class="form-label">Number Allowed</label>
                  <input type="number" name="num_allowed" min="1" value="1" class="form-control" required>
                </div>
<div class="col-md-12">
  <label class="form-label">Table Number(s)</label>
  <select class="form-control" name="table_number[]" id="table_number" multiple required>
    <?php for ($i=1;$i<=15;$i++):
      $t="G-$i"; $used=$table_counts[$t]??0; $left=max(0,10-$used);
    ?>
      <option value="<?= $t ?>" <?= $left===0?'disabled':'' ?>>
        Groom Table <?= $i ?> (<?= $used ?>/10, <?= $left ?> left)
      </option>
    <?php endfor; ?>
    <?php for ($i=1;$i<=15;$i++):
      $t="B-$i"; $used=$table_counts[$t]??0; $left=max(0,10-$used);
    ?>
      <option value="<?= $t ?>" <?= $left===0?'disabled':'' ?>>
        Bride Table <?= $i ?> (<?= $used ?>/10, <?= $left ?> left)
      </option>
    <?php endfor; ?>
  </select>
</div>

                <div class="col-12">
                  <button class="btn btn-dark w-100 mt-3">💾 Save Guest</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>

      <!-- Guest List -->
      <div class="col-12 col-lg-8">
        <div class="card h-100">
          <div class="card-body">
            <h5 class="card-title">📋 Guest List</h5>
            <div class="table-responsive">
              <table id="guestTable" class="table table-striped table-sm align-middle">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Admits</th>
                    <th>Table</th>
                    <th>Code</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($guests as $g): ?>
                  <tr>
                    <td><?= e($g['id']) ?></td>
                    <td><?= e($g['name']) ?></td>
                    <td><?= e($g['num_allowed']) ?></td>
<td>
  <?php 
    $tables = explode(',', str_replace(' ', '', $g['table_number']));
    foreach ($tables as $t): ?>
      <span class="badge bg-info text-dark me-1"><?= e($t) ?></span>
  <?php endforeach; ?>
</td>
                    <td><code><?= e($g['code']) ?></code></td>
                    <td class="d-flex gap-2">
                      <a class="btn btn-sm btn-outline-dark" target="_blank" href="preview_card.php?id=<?= e($g['id']) ?>">Preview</a>
                      <a class="btn btn-sm btn-outline-secondary" target="_blank" href="../scanner/index.php?code=<?= e($g['code']) ?>">Scanner</a>
                      <a class="btn btn-sm btn-outline-danger" href="delete_guest.php?id=<?= e($g['id']) ?>" onclick="return confirm('Delete this guest?')">Delete</a>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                  <?php if (empty($guests)): ?>
                  <tr>
                    <td colspan="6" class="text-center text-muted">No guests added yet.</td>
                  </tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Tracking Tables Row -->
    <div class="row g-4 mt-4">
      <!-- Groom Tables -->
      <div class="col-12 col-lg-6">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">👔 Groom Table Tracking</h5>
            <div class="table-responsive">
              <table id="groomTable" class="table table-bordered table-sm text-center">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Table</th>
                    <th>Seats Taken</th>
                    <th>Seats Left</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <?php for($i=1;$i<=15;$i++):
                    $t="G-$i"; $used=$table_counts[$t]??0; $left=max(0,10-$used);
                  ?>
                  <tr>
                    <td><?= e($i) ?></td>
                    <td><?= $t ?></td>
                    <td><?= $used ?>/10</td>
                    <td><?= $left ?></td>
                    <td>
                      <?php if($left==0): ?><span class="badge bg-danger">Full</span>
                      <?php elseif($left<=3): ?><span class="badge bg-warning text-dark">Almost Full</span>
                      <?php else: ?><span class="badge bg-success">Available</span>
                      <?php endif; ?>
                    </td>
                  </tr>
                  <?php endfor; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <!-- Bride Tables -->
      <div class="col-12 col-lg-6">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">👰 Bride Table Tracking</h5>
            <div class="table-responsive">
              <table id="brideTable" class="table table-bordered table-sm text-center">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Table</th>
                    <th>Seats Taken</th>
                    <th>Seats Left</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <?php for($i=1;$i<=15;$i++):
                    $t="B-$i"; $used=$table_counts[$t]??0; $left=max(0,10-$used);
                  ?>
                  <tr>
                    <td><?= e($i) ?></td>
                    <td><?= $t ?></td>
                    <td><?= $used ?>/10</td>
                    <td><?= $left ?></td>
                    <td>
                      <?php if($left==0): ?><span class="badge bg-danger">Full</span>
                      <?php elseif($left<=3): ?><span class="badge bg-warning text-dark">Almost Full</span>
                      <?php else: ?><span class="badge bg-success">Available</span>
                      <?php endif; ?>
                    </td>
                  </tr>
                  <?php endfor; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
</main>

<footer>
  <div>💐 Mesh'25 Wedding | Designed with <span>❤️</span> By Popkot Consult</div>
</footer>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
  $(document).ready(function() {
    $('#table_number').select2({ placeholder: "Select a table", allowClear: true });
  });
</script>

<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script>
  $(document).ready(function() {
    $('#guestTable').DataTable();
    $('#groomTable, #brideTable').DataTable({ paging:false, searching:false, info:false });
  });
</script>
</body>
</html>
