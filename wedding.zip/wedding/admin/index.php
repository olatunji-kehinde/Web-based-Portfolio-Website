<?php
require __DIR__ . '/../vendor/autoload.php';
use Dotenv\Dotenv;
require __DIR__ . '/../includes/helpers.php';

$dotenv = Dotenv::createImmutable(dirname(__DIR__));
$dotenv->safeLoad();
$ADMIN_PASSWORD = $_ENV['ADMIN_PASSWORD'] ?? 'secret123';

ensure_session_started();
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pass = $_POST['password'] ?? '';
    if ($pass === $ADMIN_PASSWORD) {
        $_SESSION['admin_logged_in'] = true;
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'Invalid password';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Admin Login — Mesh'25 Wedding Invites</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    body {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      background: linear-gradient(135deg, #004d4a, #007f7b);
      font-family: "Poppins", sans-serif;
      overflow: hidden;
    }

    /* Fade-in animation */
    @keyframes fadeInUp {
      from { opacity: 0; transform: translateY(40px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .login-card {
      max-width: 420px;
      width: 100%;
      border-radius: 1.5rem;
      background: #fff;
      box-shadow: 0 10px 25px rgba(0,0,0,0.15);
      padding: 2rem;
      animation: fadeInUp 1s ease-out;
    }

    .login-card h1 {
      font-weight: 600;
      color: #004d4a;
      border-bottom: 2px solid #c19a3f;
      display: inline-block;
      padding-bottom: 4px;
      animation: fadeInUp 1.3s ease-out;
    }

    .form-label {
      font-weight: 500;
      color: #004d4a;
    }

    .form-control {
      border-radius: 0.75rem;
      border: 1px solid #ccc;
      transition: all 0.3s;
    }

    .form-control:focus {
      border-color: #c19a3f;
      box-shadow: 0 0 0 0.25rem rgba(193,154,63,0.25);
    }

    .btn-login {
      background: #004d4a;
      color: #fff;
      font-weight: 500;
      border-radius: 0.75rem;
      transition: all 0.3s ease;
    }

    .btn-login:hover {
      background: #c19a3f;
      color: #fff;
      transform: translateY(-2px);
      box-shadow: 0 6px 15px rgba(193,154,63,0.4);
    }

    .password-toggle {
      cursor: pointer;
      position: absolute;
      right: 1rem;
      top: 50%;
      transform: translateY(-50%);
      color: #888;
    }

    .password-wrapper {
      position: relative;
    }

    footer {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      text-align: center;
      padding: 0.6rem 0;
      font-size: 0.9rem;
      background: rgba(0,77,74,0.95);
      color: #fff;
      border-top: 3px solid #c19a3f;
      animation: fadeInUp 1.6s ease-out;
    }
    footer span { color: #c19a3f; font-weight: 600; }
  </style>
</head>
<body>
  <div class="login-card text-center">
    <h1 class="h4 mb-4">Admin Login</h1>
    <?php if ($error): ?>
      <div class="alert alert-danger py-2"><?= e($error) ?></div>
    <?php endif; ?>
    <form method="post">
      <div class="mb-3 text-start password-wrapper">
        <label class="form-label">Password</label>
        <input type="password" id="password" name="password" class="form-control" required />
        <i class="bi bi-eye-slash password-toggle" id="togglePassword"></i>
      </div>
      <button class="btn btn-login w-100">Login</button>
    </form>
  </div>

<footer>
  <div>💐 Mesh'25 Wedding | Designed with <span>❤️</span> By Popkot Consult</div>
</footer>

<script>
  const togglePassword = document.querySelector("#togglePassword");
  const passwordField = document.querySelector("#password");

  togglePassword.addEventListener("click", function () {
    const type = passwordField.getAttribute("type") === "password" ? "text" : "password";
    passwordField.setAttribute("type", type);
    this.classList.toggle("bi-eye");
    this.classList.toggle("bi-eye-slash");
  });
</script>
</body>
</html>
