<?php
require __DIR__ . '/../includes/db.php';
require __DIR__ . '/../includes/helpers.php';
require_login();

$id = intval($_GET['id'] ?? 0);
$stmt = $conn->prepare("SELECT * FROM guests WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$res = $stmt->get_result();
$guest = $res->fetch_assoc();
$stmt->close();
if (!$guest) { http_response_code(404); echo "Guest not found."; exit; }

$hosts = "#MESH'25";
$event_date = "Saturday, October 04, 2025";
$church_time = "9:00 AM";
$church_venue = "Christ Apostolic Church,<br> Oke Igbala Area, <br>No. 3, Ibilade Street, Iyana Church, Ibadan.";
$reception_time = "11:00 AM";
$reception_venue = "Adedoyin Hall, Orebanjo Multipurpose Hall Complex, Iyana-church, Ibadan";
$dress_code = "White and Mint Green";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Invitation Card — <?= e($guest['name']) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
<!-- Add this in your <head> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>

<style>
@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500;600;700&family=Great+Vibes&family=Montserrat:wght@300;400;500&display=swap');

* { margin: 0; padding: 0; box-sizing: border-box; }

body {
    background: #f9fdfd;
    font-family: 'Cormorant Garamond', serif;
    color: #004d4a;
    padding: 20px;
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    background-image: radial-gradient(#d7ecea 1.5px, transparent 1.5px);
    background-size: 20px 20px;
}

.invitation-container { 
    max-width: 1000px; 
    width: 100%; 
    margin: 0 auto; 
    position: relative;
    perspective: 1500px;
}



.book-cover {
    position: relative;
    width: 100%;
    height: 100%;
    display: flex;
    box-shadow: 0 15px 50px rgba(0, 77, 74, 0.2);
    border-radius: 8px;
    overflow: hidden;
    background: #fff;
}

.book-page {
    position: relative;
    width: 50%;
    padding: 60px 50px;
    z-index: 2;
    background: #ffffff;
    display: flex;
    flex-direction: column;
    justify-content: center;
}

.book-page.left-page {
    border-right: 1px solid #d7ecea;
}

/* Book spine effect */
.book-spine {
    position: absolute;
    top: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 16px;
    height: 100%;
    background: linear-gradient(to right, #003d3a, #006963, #003d3a);
    z-index: 3;
    box-shadow: 
        inset -3px 0 5px rgba(0, 0, 0, 0.1),
        inset 3px 0 5px rgba(255, 255, 255, 0.1);
}

.watercolor-floral {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
    z-index: 1;
    opacity: 0.6;
}

.floral-corner {
    position: absolute;
    width: 180px;
    height: 180px;
    background-size: contain;
    background-repeat: no-repeat;
    z-index: 1;
    opacity: 0.3;
}

.floral-top-left {
    top: 0;
    left: 0;
    background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><path fill="%23004d4a" d="M30,50 C40,30 70,20 90,40 C110,60 100,90 70,100 C40,110 20,90 30,70 Z"/></svg>');
}

.floral-top-right {
    top: 0;
    right: 0;
    background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><path fill="%23004d4a" d="M170,50 C160,30 130,20 110,40 C90,60 100,90 130,100 C160,110 180,90 170,70 Z"/></svg>');
}

.floral-bottom-left {
    bottom: 0;
    left: 0;
    background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><path fill="%23004d4a" d="M30,150 C40,170 70,180 90,160 C110,140 100,110 70,100 C40,90 20,110 30,130 Z"/></svg>');
}

.floral-bottom-right {
    bottom: 0;
    right: 0;
    background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><path fill="%23004d4a" d="M170,150 C160,170 130,180 110,160 C90,140 100,110 130,100 C160,90 180,110 170,130 Z"/></svg>');
}

/* Page content styles */
.wedding-title {
    font-size: 22px;
    letter-spacing: 8px;
    text-transform: uppercase;
    font-weight: 400;
    color: #004d4a;
    margin-bottom: 30px;
    position: relative;
    text-align: center;
}

.wedding-title::after {
    content: "";
    position: absolute;
    bottom: -10px;
    left: 50%;
    transform: translateX(-50%);
    width: 80px;
    height: 1px;
    background: #a5d4c3;
}

.couple-names {
    font-family: 'Great Vibes', cursive;
    font-size: 70px;
    line-height: 0.8;
    color: #004d4a;
    margin: 30px 0;
    text-align: center;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.05);
}

.invitation-text {
    font-size: 20px;
    line-height: 1.8;
    font-weight: 400;
    color: #004d4a;
    text-align: center;
    margin-bottom: 25px;

}

.invitation-text strong {
    font-weight: 600;
    color: #004d4a;
     font-family: 'Georgia', serif; /* Change to your desired font */
    font-weight: bold; /* Keep it bold or remove if not needed */
    font-style: italic; /* Optional: italicize */
    color: #004d4a; /* Egyptian Teal Green */
    letter-spacing: 1px; /* Optional: spacing between letters */
}

.blessing {
    font-style: italic;
    font-size: 18px;
    color: #004d4a;
    padding: 0 30px;
    position: relative;
    text-align: center;
}

.blessing::before, .blessing::after {
    content: '"';
    font-size: 40px;
    color: #a5d4c3;
    position: absolute;
    top: -20px;
}

.blessing::before {
    left: 0;
}

.blessing::after {
    right: 0;
}

.divider {
    width: 100%;
    height: 1px;
    background: linear-gradient(to right, transparent, #a5d4c3, transparent);
    margin: 10px 0;
}

.event-title {
    font-family: 'Cormorant Garamond', serif;
    font-weight: 700;
    font-size: 26px;
    color: #004d4a;
    position: relative;
    display: inline-block;
    text-align: center;
    width: 100%;

}

.event-title::after {
    content: "";
    position: absolute;
    bottom: -8px;
    left: 50%;
    transform: translateX(-50%);
    width: 60px;
    height: 2px;
    background: #a5d4c3;
}

.event-details {
    font-size: 19px;
    line-height: 1.8;
    color: #004d4a;
    text-align: center;
}

.event-details p {
    margin: 15px 0;
}

.dress-code {
    font-weight: 500;
    font-size: 19px;
    color: #004d4a;
    padding: 15px 0;
    border-top: 1px solid #a5d4c3;
    border-bottom: 1px solid #a5d4c3;
    text-align: center;
}

.guest-info {
    font-size: 20px;
    font-weight: 500;
    margin: 40px 0 30px;
    color: #004d4a;
    text-align: center;
}

.guest-info strong {
    color: #004d4a;
    font-weight: 600;
}

.meta {
    display: flex;
    justify-content: center;
    gap: 30px;
    margin: 40px 0;
}

.meta .pill {
    border: 1px solid #a5d4c3;
    padding: 12px 30px;
    border-radius: 30px;
    background: #f9fdfd;
    font-weight: 500;
    font-size: 18px;
    color: #004d4a;
    font-family: 'Montserrat', sans-serif;
}

.qr-area {
 margin: 20px 0 15px; /* Reduced vertical spacing */
    display: flex;
    flex-direction: column;
    align-items: center;
}

#qrcode {
    background: white;
    padding: 12px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
}

.small-note {
    color: #004d4a;
    font-size: 15px;
    max-width: 260px;
    line-height: 1.5;
    font-family: 'Montserrat', sans-serif;
    margin-top: 15px;
    text-align: center;
}

.rsvp-section {
    font-size: 18px;
    font-weight: 500;
    border-top: 1px solid #a5d4c3;
    color: #004d4a;
    text-align: center;
    border-bottom: 1px solid #a5d4c3;
    margin-top: 15px; /* Reduced top margin */
    padding-top: 20px; /* Reduced padding */

}

.rsvp-section p {
    margin-bottom: 20px;
    letter-spacing: 1px;
    font-family: 'Montserrat', sans-serif;
}

.rsvp-section ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
}

.rsvp-section ul li {
    margin: 12px 0;
    font-size: 17px;
}

.rsvp-section ul li strong {
    color: #004d4a;
    font-weight: 500;
}

.print-actions {
    display: flex;
    justify-content: center;
    gap: 20px;
    margin-top: 30px;
}

.btn {
    padding: 12px 30px;
    border-radius: 30px;
    font-family: 'Montserrat', sans-serif;
    font-weight: 500;
    font-size: 16px;
    cursor: pointer;
    border: none;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    gap: 8px;
}

.btn-print {
    background: linear-gradient(45deg, #004d4a, #007f79);
    color: white;
    box-shadow: 0 4px 15px rgba(0, 77, 74, 0.3);
}

.btn-print:hover {
    background: linear-gradient(45deg, #003d3a, #006963);
    transform: translateY(-2px);
}

.btn-scan {
    background: transparent;
    border: 1px solid #004d4a;
    color: #004d4a;
}

.btn-scan:hover {
    background: #e1f2f0;
    transform: translateY(-2px);
}

/* Page curl effect */
.book-page::before {
    content: '';
    position: absolute;
    top: 0;
    right: -1px;
    width: 20px;
    height: 100%;
    background: linear-gradient(to right, rgba(0, 0, 0, 0.03), transparent);
    z-index: 2;
}
@media print {
    @page {
        size: A4; /* Paper size: A4 */
        margin: 0.75cm; /* Default margins */
        marks: crop cross; /* Show crop marks */
    }

    body {
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        background: white !important;
        padding: 0;
        background-image: none !important;
        transform: scale(1); /* Ensure no scaling */
    }

    .invitation-container {
        max-width: 100%;
        width: 100%;
        margin: 0;
        box-shadow: none;
        transform: none;
    }

    .book-cover {
        box-shadow: none;
        transform: none;
        height: 100%;
    }

    .book-page {
        padding: 25px;
        height: 100vh;
    }

    /* Explicitly show background graphics */
    .watercolor-floral,
    .floral-corner {
        opacity: 1 !important;
        display: block !important;
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
    }

    .print-actions {
        display: none;
    }

    /* Ensure QR code prints correctly */
    #qrcode img {
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
        filter: none !important;
    }
}
/* MAP STYLES */
.map-section {
    margin: 20px 0 10px;
    text-align: center;
}

.map-section h2 {
    font-family: 'Cormorant Garamond', serif;
    font-weight: 600;
    font-size: 20px;
    color: #004d4a;
    margin-bottom: 12px;
    position: relative;
}

.map-section h2::after {
    content: "";
    position: absolute;
    bottom: -6px;
    left: 50%;
    transform: translateX(-50%);
    width: 80px;
    height: 1px;
    background: #a5d4c3;
}

#roadMap {
  width: 100%;
  max-width: 400px;
  height: auto;
  display: block;
  margin: 20px auto;
  border-radius: 10px;
  border: 1px solid #d7ecea;
}

</style>
</head>
<body>
    <div class="invitation-container">
        <div class="book-cover">
            <div class="watercolor-floral">
                <div class="floral-corner floral-top-left"></div>
                <div class="floral-corner floral-top-right"></div>
                <div class="floral-corner floral-bottom-left"></div>
                <div class="floral-corner floral-bottom-right"></div>
            </div>
            
            <div class="book-spine"></div>
            
            <!-- Left Page -->
            <div class="book-page left-page">
                <div class="wedding-title">Wedding Invitation</div>
                <div class="couple-names">Mercy <br>&<br> Stephen</div>
                
                <div class="invitation-text">
                    <p>
                        The families of <br><strong>Dr. & Lady Evang. Alamu Olatunji</strong> <br>and <br><strong>Mr. & Mrs. S.K Adeleke</strong> <br>
                        joyfully invite you, <?= e($guest['name']) ?>, <br>
                        to join them in celebrating the union of their children in holy matrimony.
                    </p>
                </div>
                <div class="divider"></div>
                <div class="blessing">
                    “And over all these virtues put on love, which binds them all together in perfect unity.” – Colossians 3:14
                </div>
                
                <div class="divider"></div>
                
                <!-- Church Wedding Section -->
                <div class="event-section">
                    <div class="event-title">Holy Matrimony</div>
                    <div class="event-details">
                        <p><strong>Date:</strong><br> <?= e($event_date) ?></p>
                        <p><strong>Time:</strong><br> <?= e($church_time) ?></p>
<p><strong>Venue:</strong><br> <?= $church_venue ?></p>
                    </div>
                </div>
                
                <div class="dress-code">
                    <strong>Dress Code:</strong> <?= e($dress_code) ?>
                </div>
                <center>
                    <strong><?php echo $hosts; ?></strong>
                </center>

            </div>
            
            <!-- Right Page -->
            <div class="book-page">
                <!-- Reception Section -->
                <div class="event-section">
                    <div class="event-title">Engagement Ceremony & Reception</div>
                    <div class="event-details">
                        <p><strong>Time:</strong> <?= e($reception_time) ?></p>
                        <p><strong>Venue:</strong> <?= e($reception_venue) ?></p>
                    </div>
                </div>
                
                <div class="guest-info">
                    <strong>Guest Name:</strong> <?= e($guest['name']) ?>
                </div>
                
                <div class="meta">
                    <div class="pill">Table: <strong><?= e($guest['table_number']) ?></strong></div>
                </div>
                
                <div class="qr-area">
                    <div id="qrcode"></div>
                    <div class="small-note">Please present this QR code at the entrance for swift check-in</div>
                </div>
                <div class="map-section">
                    <h2>Road Map to Event Venue</h2>
                    <canvas id="roadMap"></canvas>
                </div>
                <div class="rsvp-section">
                    <p>R.S.V.P</p>
                    <ul>
                        <li><strong>Mr. Kehinde Olatunji:</strong> +234 814 259 5976</li>
                        <li><strong>Mrs. Olayinka Oyewumi:</strong> +234 806 857 8886</li>
                    </ul>
                </div>
                                <center>
                    <strong><?php echo $hosts; ?></strong>
                </center>
            </div>
        </div>
        
        <div class="print-actions">
            <button class="btn btn-print" onclick="window.print()">
                <i class="fas fa-print"></i> Print Invitation
            </button>
            <button class="btn btn-print" id="btnDownloadPDF">
                <i class="fas fa-file-pdf"></i> Download PDF
            </button>
            <a class="btn btn-scan" href="../scanner/index.php?code=<?= e($guest['code']) ?>" target="_blank">
                <i class="fas fa-qrcode"></i> Test QR Scan
            </a>
        </div>
    </div>

<script>
document.getElementById("btnDownloadPDF").addEventListener("click", () => {
    const { jsPDF } = window.jspdf;
    const container = document.querySelector(".invitation-container");
    const printActions = document.querySelector(".print-actions");

    // Detect device
    const ua = navigator.userAgent;
    const isIOS = /iPhone|iPad|iPod/i.test(ua);
    const isAndroid = /Android/i.test(ua);

    // Hide buttons temporarily
    printActions.style.display = "none";

    html2canvas(container, {
        scale: 2,
        useCORS: true
    }).then((canvas) => {
        const imgData = canvas.toDataURL("image/png");

        const pdf = new jsPDF({
            orientation: "portrait",
            unit: "pt",
            format: "a4"
        });

        const a4Width = 595;
        const a4Height = 842;

        const imgWidth = canvas.width;
        const imgHeight = canvas.height;
        const scale = Math.min(a4Width / imgWidth, a4Height / imgHeight);

        const pdfWidth = imgWidth * scale;
        const pdfHeight = imgHeight * scale;

        pdf.addImage(
            imgData,
            "PNG",
            (a4Width - pdfWidth) / 2,
            (a4Height - pdfHeight) / 2,
            pdfWidth,
            pdfHeight
        );

        if (isIOS || isAndroid) {
            // Mobile: open in new tab instead of direct download
            window.open(pdf.output("bloburl"), "_blank");
        } else {
            // Desktop: trigger download
            pdf.save("E-Invitation-<?= e($guest['name']) ?>.pdf");
        }

        // Restore buttons
        printActions.style.display = "flex";
    });
});
</script>



    

<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <script>
    // QR Code
    const code = "<?= e($guest['code']) ?>";
    new QRCode(document.getElementById("qrcode"), {
        text: code,
        width: 180,
        height: 180,
        correctLevel: QRCode.CorrectLevel.M
    });
    </script>

<script>
const canvas = document.getElementById("roadMap");
const ctx = canvas.getContext("2d");
const width = canvas.width = 950; 
const height = canvas.height = 420;

// Background
ctx.fillStyle = "#f9fdfd";
ctx.fillRect(0, 0, width, height);

// === MAIN ROAD ===
ctx.strokeStyle = "#a5d4c3";
ctx.lineWidth = 30;
ctx.lineCap = "round";
ctx.beginPath();
ctx.moveTo(0, 150);   
ctx.lineTo(width, 150); 
ctx.stroke();
// Center dashed line
ctx.strokeStyle = "#fff";
ctx.lineWidth = 3;
ctx.setLineDash([20, 20]);
ctx.beginPath();
ctx.moveTo(0, 150);
ctx.lineTo(width, 150);
ctx.stroke();
ctx.setLineDash([]);

// === SIDE ROADS ===

// 1. First Turning to Church (opposite Stanbic Bank)
ctx.strokeStyle = "#a5d4c3";
ctx.lineWidth = 25;
ctx.beginPath();
ctx.moveTo(300, 150);
ctx.bezierCurveTo(490, 200, 480, 280, 500, 360); 
ctx.stroke();

// Church road marking
ctx.strokeStyle = "#fff";
ctx.lineWidth = 2;
ctx.setLineDash([12, 12]);
ctx.beginPath();
ctx.moveTo(500, 150);
ctx.bezierCurveTo(490, 200, 480, 280, 500, 360);
ctx.stroke();
ctx.setLineDash([]);

// 2. Service Lane (longer curve to Orebanjo Hall)
ctx.strokeStyle = "#a5d4c3";
ctx.lineWidth = 20;
ctx.beginPath();
ctx.moveTo(600, 150);
ctx.bezierCurveTo(560, 170, 750, 190, 930, 190);
ctx.stroke();

// Dashed markings
ctx.strokeStyle = "#fff";
ctx.lineWidth = 2;
ctx.setLineDash([12, 12]);
ctx.beginPath();
ctx.moveTo(550, 150);
ctx.bezierCurveTo(560, 170, 750, 190, 930, 190);
ctx.stroke();
ctx.setLineDash([]);

// === LANDMARK LABELS ===
function drawText(x, y, text, align="center") {
    ctx.fillStyle = "#004d4a";
    ctx.font = "bold 16px Arial";
    ctx.textAlign = align;
    const lines = text.split("\n");
    lines.forEach((line, i) => {
        ctx.fillText(line, x, y + (i*18));
    });
}

// Road ends
drawText(60, 150, "IWO ROAD\nJunction");
drawText(710, 150, "IYANA CHURCH\nJunction");

// Landmarks (corrected positions)
drawText(300, 120, "Stanbic Ibtc Bank");       // above road
drawText(520, 200, "Gasland\nPlant");    // BELOW road beside turning
drawText(500, 390, "C.A.C\n Oke Igbala");  
drawText(850, 220, "Orebanjo\nMultipurpose Hall");     // at service lane end

// === ARROWS ===
ctx.fillStyle = "#004d4a";

// Main road arrow
ctx.beginPath();
ctx.moveTo(500, 140);
ctx.lineTo(520, 150);
ctx.lineTo(500, 160);
ctx.closePath();
ctx.fill();

// Church road arrow
ctx.beginPath();
ctx.moveTo(490, 250);
ctx.lineTo(500, 270);
ctx.lineTo(510, 250);
ctx.closePath();
ctx.fill();

// Service lane arrow (extended)
ctx.beginPath();
ctx.moveTo(800, 180);
ctx.lineTo(820, 190);
ctx.lineTo(800, 200);
ctx.closePath();
ctx.fill();
</script>
</body>
</html>