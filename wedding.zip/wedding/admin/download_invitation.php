<?php
require __DIR__ . '/../includes/db.php';
require __DIR__ . '/../vendor/autoload.php'; // mPDF

$id = intval($_GET['id'] ?? 0);
$stmt = $conn->prepare("SELECT * FROM guests WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$guest = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$guest) die("Guest not found.");

// Load the invitation HTML (reuse your existing template)
ob_start();
include 'preview_card.php'; // Make sure it works standalone
$html = ob_get_clean();

$mpdf = new \Mpdf\Mpdf(['format' => 'A4']);
$mpdf->WriteHTML($html);
$mpdf->Output("invitation-{$guest['name']}.pdf", 'D'); // Force download
