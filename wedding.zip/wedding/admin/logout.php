<?php
require __DIR__ . '/../includes/helpers.php';
ensure_session_started();
session_destroy();
header('Location: index.php');
exit;
