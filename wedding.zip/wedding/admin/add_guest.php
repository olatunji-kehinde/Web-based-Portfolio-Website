<?php
require __DIR__ . '/../includes/db.php';
require __DIR__ . '/../includes/helpers.php';
require_login();

$name = trim($_POST['name'] ?? '');
$num_allowed = intval($_POST['num_allowed'] ?? 1);
$tables = [];

if (isset($_POST['table_number'])) {
    if (is_array($_POST['table_number'])) {
        $tables = array_map('trim', $_POST['table_number']); // multi-select or checkbox
    } else {
        $tables = array_map('trim', explode(',', $_POST['table_number'])); // comma separated string
    }
}

if ($name && !empty($tables) && $num_allowed > 0) {
    // Generate shared code
    $code = generate_code();

    // Calculate total available seats across all selected tables
    $total_capacity = 0;

    foreach ($tables as $table_number) {
        $table_number = trim($table_number);

        // Check current occupancy for this table
        $stmt = $conn->prepare("SELECT COALESCE(SUM(num_allowed), 0) AS total FROM guests WHERE FIND_IN_SET(?, table_number)");
        $stmt->bind_param("s", $table_number);
        $stmt->execute();
        $res = $stmt->get_result();
        $row = $res->fetch_assoc();
        $stmt->close();

        $current_total = intval($row['total']);
        $available = max(0, 10 - $current_total); // max 10 seats per table
        $total_capacity += $available;
    }

    // Check if request exceeds available seats
    if ($num_allowed > $total_capacity) {
        header("Location: dashboard.php?error=NotEnoughSeats&available=$total_capacity");
        exit;
    }

    // Save one row with all tables joined as string
    $tables_str = implode(',', array_map('trim', $tables));

    $stmt = $conn->prepare("INSERT INTO guests (code, name, num_allowed, table_number, checked_in_count) VALUES (?, ?, ?, ?, 0)");
    $stmt->bind_param("ssis", $code, $name, $num_allowed, $tables_str);
    $stmt->execute();
    $stmt->close();

    header('Location: dashboard.php?success=1&code=' . urlencode($code));
    exit;
}

header('Location: dashboard.php?error=InvalidInput');
exit;
