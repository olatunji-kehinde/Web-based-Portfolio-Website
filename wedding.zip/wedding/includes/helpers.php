<?php
// includes/helpers.php

function ensure_session_started() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

function is_logged_in() {
    ensure_session_started();
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

function require_login() {
    if (!is_logged_in()) {
        header('Location: /admin/index.php');
        exit;
    }
}

function e($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

function generate_code() {
    // Create a short unique code (base36) for the QR payload
    $bytes = random_bytes(8);
    return strtoupper(bin2hex($bytes));
}
?>
